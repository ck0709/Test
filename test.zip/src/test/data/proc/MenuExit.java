package test.data.proc;

public class MenuExit {
	public void proc() {
		System.out.println("프로그램을 종료합니다.");
	}
}