package test;


public class Main {
	public static void main(String[] args) {
		Sky sky = new Sky();
		sky.proc();
	}
}